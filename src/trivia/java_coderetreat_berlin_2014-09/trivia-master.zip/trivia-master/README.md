Legacy Code Retreat code base
======

Use this code base to run your own [Legacy Code Retreat](http://www.legacycoderetreat.org).

Did your Legacy Code Retreat go well? You could thank me with a flattr: <a href="http://flattr.com/thing/1075656/" target="_blank">
<img src="http://api.flattr.com/button/flattr-badge-large.png" alt="Flattr this" title="Flattr this" border="0" /></a>
