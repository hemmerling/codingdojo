# This ensures you're using the gem rather than minitest shipped with Ruby.
gem 'minitest'

require 'minitest/autorun'