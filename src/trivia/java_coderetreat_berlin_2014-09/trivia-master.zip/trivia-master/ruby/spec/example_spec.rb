require 'spec_helper'

describe "example test" do
  it "should pass" do
    true.should == true
  end
end