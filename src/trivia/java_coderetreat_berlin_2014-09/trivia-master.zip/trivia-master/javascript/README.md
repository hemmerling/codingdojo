Test with node.js
=====================

Install the jasmine-node plugin from https://github.com/mhevery/jasmine-node

	npm install jasmine-node -g

And execute:

	jasmine-node .

Any test source matching the pattern *.spec.js will be executed.
