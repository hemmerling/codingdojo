
compile with dub
================

1. install dub : [from here](http://code.dlang.org/download)
2. compile & run with :
	dub run


compile with dmd
================

	dmd source/trivia.d source/game.d

and run :
	./trivia


