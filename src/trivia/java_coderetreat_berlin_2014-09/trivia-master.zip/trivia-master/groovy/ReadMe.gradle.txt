
- install Gradle from http://www.gradle.org/downloads

- commands:
	gradle clean
	gradle build 
		- see ~/build/classes/main for JVM class files
