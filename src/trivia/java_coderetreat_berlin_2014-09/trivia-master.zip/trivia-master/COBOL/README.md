Compiled using Open COBOL 1.0-5 http://sourceforge.net/projects/open-cobol/

cobc -x game.cob 
-x provides an executable

./game

For easy testing: cobc -x game.cob && ./game